<html>
    <head>
        <title>HOME--page</title>
        <link rel="stylesheet" href="css/home.css">
    </head>
    <body>
        <div class="b" >
        <div class="a">
            <h2> USER LOGIN AND REGISTRATION SYSTEM</h2>
        </div>
        <div>
            <a href="login.php"><h3 class="l1">LOGIN</h3></a>
        </div>
        <div>
             <a href="regis.php"><h3 class="l2">REGISER</h3></a>
        </div>
    </div>
    </body>
</html>